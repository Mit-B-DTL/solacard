jQuery(document).ready(function ($) {
    $(".list-layout").click(function () {
        $(".card-item__grid").addClass("list_layout");
    });
    $(".grid-layout").click(function () {
        $(".card-item__grid").removeClass("list_layout");
    });
    $(".toggle-menu").click(function () {
        $(".card-header__nav-menu").toggleClass("nav-menu-active");
    });

    $(".list-layout").click(function () {
        $(".card-item__grid").addClass("list_layout");
    });

    // toggle open
    $(".toggle-menu").click(function () {
        $(".toggle-menu").toggleClass("toggle-open");
    });
    // toggle resize
    $(window).resize(function () {
        if ($(window).width() > 991) {
            $(".card-header__nav-menu").css("display", "flex");
        } else {
            $(".card-header__nav-menu").css("display", "none");
            $(".card-header__nav-menu").removeClass("nav-menu-active");
            $(".toggle-menu").removeClass("toggle-open");

        }
    });
    // FAQ
    $(".faq-discription__list").hide();
    $(".faq-discription__item").click(function () {
        if ($(this).hasClass("active")) {
            $(this).removeClass("active").next(".faq-discription__list").slideUp();
        } else {
            $(".faq-discription__item").removeClass("active");
            $(".faq-discription__list").slideUp();
            $(this).addClass("active").next(".faq-discription__list").slideDown();
        }
    });

});